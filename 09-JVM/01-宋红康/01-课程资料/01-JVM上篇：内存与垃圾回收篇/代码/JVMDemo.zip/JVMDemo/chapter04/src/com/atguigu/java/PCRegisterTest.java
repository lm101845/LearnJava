package com.atguigu.java;

/**
 * @author shkstart
 * @create 2020 下午 6:46
 */
public class PCRegisterTest {

    public static void main(String[] args) {
        int i = 10;
        int j = 20;
        int k = i + j;

        String s = "abc";
        System.out.println(i);
        System.out.println(k);

    }
}
