package java.lang;

/**
 * @author shkstart
 * @create 2020 下午 12:00
 */
public class ShkStart {

    public static void main(String[] args) {
        System.out.println("hello!");
    }
}
