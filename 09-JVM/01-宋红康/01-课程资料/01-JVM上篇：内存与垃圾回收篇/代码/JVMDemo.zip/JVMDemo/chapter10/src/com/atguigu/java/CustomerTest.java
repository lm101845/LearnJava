package com.atguigu.java;

/**
 * @author shkstart  shkstart@126.com
 * @create 2020  18:42
 */
public class CustomerTest {
    public static void main(String[] args) {
        Customer cust = new Customer();
    }
}
