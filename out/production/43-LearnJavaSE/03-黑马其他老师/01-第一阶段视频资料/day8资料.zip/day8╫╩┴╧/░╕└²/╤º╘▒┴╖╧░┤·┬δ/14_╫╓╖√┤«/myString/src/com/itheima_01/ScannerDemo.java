package com.itheima_01;

/*
    Scanner:
        用于获取键盘录入数据。(基本数据类型，字符串数据)

    public String nextLine()：
        获取键盘录入字符串数据
 */
public class ScannerDemo {
    public static void main(String[] args) {
        
    }
}
