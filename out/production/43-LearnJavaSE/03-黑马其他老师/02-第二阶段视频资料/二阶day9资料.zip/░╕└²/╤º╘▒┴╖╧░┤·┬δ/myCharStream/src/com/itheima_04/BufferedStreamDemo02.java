package com.itheima_04;

/*
    字符缓冲流的特有功能
        BufferedWriter：
            void newLine()：写一行行分隔符，行分隔符字符串由系统属性定义

        BufferedReader：
            public String readLine()：读一行文字。
                结果包含行的内容的字符串，不包括任何行终止字符，如果流的结尾已经到达，则为null
 */
public class BufferedStreamDemo02 {
    public static void main(String[] args) {
        
    }
}
