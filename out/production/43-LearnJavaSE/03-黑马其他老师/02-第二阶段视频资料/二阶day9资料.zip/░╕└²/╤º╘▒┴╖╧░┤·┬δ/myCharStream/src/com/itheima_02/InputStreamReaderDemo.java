package com.itheima_02;
/*
    构造方法：
        InputStreamReader​(InputStream in)：创建一个使用默认字符集的InputStreamReader

    读数据的2种方式：
        int read​()：一次读一个字符数据
        int read​(char[] cbuf)：一次读一个字符数组数据
 */
public class InputStreamReaderDemo {
    public static void main(String[] args) {
        
    }
}
