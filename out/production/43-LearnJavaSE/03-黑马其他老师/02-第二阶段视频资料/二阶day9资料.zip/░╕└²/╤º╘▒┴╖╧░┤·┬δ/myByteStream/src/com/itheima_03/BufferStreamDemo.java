package com.itheima_03;

/*
    字节缓冲流：
        BufferOutputStream
        BufferedInputStream

    构造方法：
        字节缓冲输出流：BufferedOutputStream​(OutputStream out)
        字节缓冲输入流：BufferedInputStream​(InputStream in)
 */
public class BufferStreamDemo {
    public static void main(String[] args) {
        
    }
}
