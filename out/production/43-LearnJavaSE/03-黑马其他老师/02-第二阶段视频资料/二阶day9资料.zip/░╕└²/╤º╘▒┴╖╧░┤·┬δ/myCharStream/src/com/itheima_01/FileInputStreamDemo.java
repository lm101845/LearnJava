package com.itheima_01;

/*
    需求：字节流读文本文件数据
 */
public class FileInputStreamDemo {
    public static void main(String[] args) {
        
    }
}
