package com.itheima_03;

public class InterImpl implements Inter {

}
