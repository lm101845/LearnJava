package com.itheima_03;

public interface Converter {
    int convert(String s);
}
