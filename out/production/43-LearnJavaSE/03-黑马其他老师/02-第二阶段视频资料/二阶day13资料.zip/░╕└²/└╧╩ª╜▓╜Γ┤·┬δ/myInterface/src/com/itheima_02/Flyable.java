package com.itheima_02;

public interface Flyable {
    public static void test() {
        System.out.println("Flyable 中的静态方法执行了");
    }
}
