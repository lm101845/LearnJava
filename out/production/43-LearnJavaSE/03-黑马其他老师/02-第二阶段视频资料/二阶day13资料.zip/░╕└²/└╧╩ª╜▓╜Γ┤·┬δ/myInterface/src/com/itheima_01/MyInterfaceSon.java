package com.itheima_01;

public interface MyInterfaceSon extends MyInterface {
    void show3();
}
