package com.itheima_06;

public interface StudentBuilder {
    Student build(String name,int age);
}
