package com.itheima_02;

public class InterImpl implements Inter,Flyable {
    @Override
    public void show() {
        System.out.println("show方法执行了");
    }
}
