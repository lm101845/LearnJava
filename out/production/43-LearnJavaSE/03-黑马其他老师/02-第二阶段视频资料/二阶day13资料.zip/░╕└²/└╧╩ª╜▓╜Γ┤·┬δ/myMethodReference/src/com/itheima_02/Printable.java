package com.itheima_02;

public interface Printable {
    void printInt(int i);
}
