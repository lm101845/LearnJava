package com.itheima_01;

public interface Printable {
    void printString(String s);
}
