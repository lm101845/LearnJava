package com.itheima_05;

public interface MyString {
    String mySubString(String s,int x,int y);
}
