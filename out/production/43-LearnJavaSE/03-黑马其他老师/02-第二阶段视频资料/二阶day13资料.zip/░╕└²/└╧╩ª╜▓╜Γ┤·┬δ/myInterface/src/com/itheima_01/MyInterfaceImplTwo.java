package com.itheima_01;

public class MyInterfaceImplTwo implements MyInterface {
    @Override
    public void show1() {
        System.out.println("Two show1");
    }

    @Override
    public void show2() {
        System.out.println("Two show2");
    }
}
