package com.itheima_04;

public interface Printer {
    void printUpperCase(String s);
}
