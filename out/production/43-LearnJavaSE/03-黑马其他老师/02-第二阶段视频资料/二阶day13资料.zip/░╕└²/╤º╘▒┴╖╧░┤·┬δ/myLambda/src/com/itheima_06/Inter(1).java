package com.itheima_06;

public interface Inter {
    void show();
}
