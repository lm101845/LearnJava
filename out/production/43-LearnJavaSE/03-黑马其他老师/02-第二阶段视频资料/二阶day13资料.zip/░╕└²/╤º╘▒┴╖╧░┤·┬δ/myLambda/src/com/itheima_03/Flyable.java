package com.itheima_03;

public interface Flyable {
    void fly(String s);
}
