package com.itheima_05;

public interface Flyable {
    void fly(String s);
}
