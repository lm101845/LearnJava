package com.itheima_07;

public abstract class Animal {
    public abstract void method();
}