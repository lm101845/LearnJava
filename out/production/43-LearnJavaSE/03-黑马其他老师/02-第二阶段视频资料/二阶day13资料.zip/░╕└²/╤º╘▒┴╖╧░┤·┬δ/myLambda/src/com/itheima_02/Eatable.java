package com.itheima_02;

public interface Eatable {
    void eat();
}
