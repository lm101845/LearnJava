package com.itheima_06;

/*
    Lambda表达式的注意事项
 */
public class LambdaDemo {
    public static void main(String[] args) {
		
    }

    private static void useInter(Inter i) {
        i.show();
    }
}
