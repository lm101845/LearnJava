package com.itheima_07;

public class Student {
    public void study() {
        System.out.println("爱生活，爱Java");
    }
}