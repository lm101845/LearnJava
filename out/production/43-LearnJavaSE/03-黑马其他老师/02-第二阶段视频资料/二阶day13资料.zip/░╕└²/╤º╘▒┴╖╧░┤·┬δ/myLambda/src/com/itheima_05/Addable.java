package com.itheima_05;

public interface Addable {
    int add(int x, int y);
}
