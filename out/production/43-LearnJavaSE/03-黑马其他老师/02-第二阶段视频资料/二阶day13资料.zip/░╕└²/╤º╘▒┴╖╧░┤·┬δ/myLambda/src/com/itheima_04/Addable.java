package com.itheima_04;

public interface Addable {
    int add(int x,int y);
}
