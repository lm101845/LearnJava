package com.itheima_07;

public interface Inter {
    void show();
}
