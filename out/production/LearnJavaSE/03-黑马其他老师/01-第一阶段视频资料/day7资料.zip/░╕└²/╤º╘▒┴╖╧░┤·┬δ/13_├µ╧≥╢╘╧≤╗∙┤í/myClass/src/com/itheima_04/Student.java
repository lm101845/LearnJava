package com.itheima_04;

/*
    学生类
 */
public class Student {
    //成员变量
    String name;
	int age;

    //成员方法
    public void show() {
        System.out.println(name + "," + age);
    }
}
