package com.itheima_03;
/*
    学生类
 */
public class Student {
    //成员变量
    String name;
    int age;

    //成员方法
    public void study() {
        System.out.println("好好学习");
    }

    public void doHomework() {
        System.out.println("多做练习");
    }
}
