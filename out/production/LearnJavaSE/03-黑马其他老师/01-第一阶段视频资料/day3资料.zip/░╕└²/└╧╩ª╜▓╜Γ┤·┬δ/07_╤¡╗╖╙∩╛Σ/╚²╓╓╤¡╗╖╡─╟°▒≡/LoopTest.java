/*
	����ѭ��������
 */
public class LoopTest {
    public static void main(String[] args) {
		/*
		//forѭ��
		for(int i = 3; i<3; i++) {
			System.out.println("�Ұ�Java");
		}
		System.out.println("--------");
		
		//whileѭ��
		int j = 3;
		while(j<3) {
			System.out.println("�Ұ�Java");
			j++;
		}
		System.out.println("--------");
		
		//do...whileѭ��
		int k = 3;
		do {
			System.out.println("�Ұ�Java");
			k++;
		}while(k<3);
		*/
		
		/*
		//forѭ��
		for(int i = 1; i<3; i++) {
			System.out.println("�Ұ�Java");
		}
		//System.out.println(i);
		System.out.println("--------");
		
		//whileѭ��
		int j = 1;
		while(j<3) {
			System.out.println("�Ұ�Java");
			j++;
		}
		System.out.println(j);
		System.out.println("--------");
		*/
		
		//��ѭ��
		/*
		for(;;) {
			System.out.println("for");
		}
		*/
		
		/*
		while(true) {
			System.out.println("while");
		}
		*/
		
		do {
			System.out.println("do...while");
		}while(true);
		
		
    }
}