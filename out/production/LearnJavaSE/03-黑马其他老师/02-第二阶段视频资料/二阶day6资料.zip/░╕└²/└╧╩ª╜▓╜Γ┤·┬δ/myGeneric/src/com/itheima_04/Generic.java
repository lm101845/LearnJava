package com.itheima_04;

public interface Generic<T> {
    void show(T t);
}
