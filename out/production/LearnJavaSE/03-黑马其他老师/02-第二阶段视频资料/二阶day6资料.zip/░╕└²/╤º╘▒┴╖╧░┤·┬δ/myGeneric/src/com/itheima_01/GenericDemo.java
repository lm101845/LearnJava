package com.itheima_01;

/*
    需求：Collection集合存储字符串并遍历
 */
public class GenericDemo {
    public static void main(String[] args) {

    }
}
