package com.itheima_04;

/*
    测试类
 */
public class GenericDemo {
    public static void main(String[] args) {

    }
}
