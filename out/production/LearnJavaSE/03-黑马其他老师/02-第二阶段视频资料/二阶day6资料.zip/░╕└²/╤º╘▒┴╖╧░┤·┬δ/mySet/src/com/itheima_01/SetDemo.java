package com.itheima_01;

/*
    Set集合特点
        不包含重复元素的集合
        没有带索引的方法，所以不能使用普通for循环遍历
 */
public class SetDemo {
    public static void main(String[] args) {

    }
}
