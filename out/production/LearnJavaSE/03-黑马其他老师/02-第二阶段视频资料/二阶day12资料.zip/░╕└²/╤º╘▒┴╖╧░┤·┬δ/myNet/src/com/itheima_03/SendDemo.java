package com.itheima_03;

/*
    UDP发送数据：
        数据来自于键盘录入，直到输入的数据是886，发送数据结束
 */
public class SendDemo {
    public static void main(String[] args) {
        //创建发送端的Socket对象(DatagramSocket)


        //创建数据，并把数据打包
		
		
        //调用DatagramSocket对象的方法发送数据

		
        //关闭发送端

    }
}
