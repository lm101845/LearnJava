package com.itheima_05;

/*
    客户端：发送数据，接收服务器反馈
 */
public class ClientDemo {
    public static void main(String[] args) {
        //创建客户端的Socket对象(Socket)

		
        //获取输出流，写数据

		
        //接收服务器反馈

		
        //释放资源

    }
}
