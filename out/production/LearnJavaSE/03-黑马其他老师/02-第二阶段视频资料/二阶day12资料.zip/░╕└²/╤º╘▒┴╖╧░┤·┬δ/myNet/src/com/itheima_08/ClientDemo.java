package com.itheima_08;

/*
    客户端：数据来自于文本文件
 */
public class ClientDemo {
    public static void main(String[] args) {
        
    }
}
