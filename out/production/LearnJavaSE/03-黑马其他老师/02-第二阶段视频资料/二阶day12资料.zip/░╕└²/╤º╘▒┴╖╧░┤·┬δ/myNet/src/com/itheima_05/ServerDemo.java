package com.itheima_05;

/*
    服务器：接收数据，给出反馈
 */
public class ServerDemo {
    public static void main(String[] args) {
        //创建服务器端的Socket对象(ServerSocket)

        //监听客户端连接，返回一个Socket对象

        //获取输入流，读数据，并把数据显示在控制台

        //给出反馈

        //释放资源
		
    }
}
