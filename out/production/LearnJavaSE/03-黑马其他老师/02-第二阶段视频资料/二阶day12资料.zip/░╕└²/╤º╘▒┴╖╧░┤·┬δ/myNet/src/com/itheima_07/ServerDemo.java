package com.itheima_07;
/*
    服务器：接收到的数据写入文本文件
 */
public class ServerDemo {
    public static void main(String[] args) {
        
    }
}
