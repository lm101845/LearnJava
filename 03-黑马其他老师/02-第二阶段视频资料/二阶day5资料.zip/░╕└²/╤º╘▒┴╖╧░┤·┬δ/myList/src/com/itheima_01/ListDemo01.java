package com.itheima_01;

/*
    List集合特点
        有序：存储和取出的元素顺序一致
        可重复：存储的元素可以重复
 */
public class ListDemo01 {
    public static void main(String[] args) {
        
    }
}
