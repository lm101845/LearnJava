package com.itheima_06;

/*
    练习2：通过配置文件运行类中的方法
 */
public class ReflectTest02 {
    public static void main(String[] args) {
		
    }
}
