package com.itheima_03;

/*
    通过反射实现如下的操作：
        Student s = new Student("林青霞");
        System.out.println(s);
 */
public class ReflectDemo03 {
    public static void main(String[] args) {
		
    }
}
