package com.itheima_06;

public class Student {
    public void study() {
        System.out.println("好好学习天天向上");
    }
}
