package com.itheima_06;

public class Teacher {
    public void teach() {
        System.out.println("用爱成就学员");
    }
}
