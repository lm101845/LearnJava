package com.itheima_03;

public interface MyService {
    void service();
}
