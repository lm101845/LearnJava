package com.itheima_03.impl;

import com.itheima_03.MyService;

public class Itheima implements MyService {
    @Override
    public void service() {
        System.out.println("学IT，来黑马");
    }
}
