package com.itheima_03.impl;

import com.itheima_03.MyService;

public class Czxy implements MyService {
    @Override
    public void service() {
        System.out.println("上大学，来传智学院，一所不一样的大学，收获不一样的你");
    }
}
