import com.itheima_03.MyService;

module myTwo {
    requires myOne;

    uses MyService;
}