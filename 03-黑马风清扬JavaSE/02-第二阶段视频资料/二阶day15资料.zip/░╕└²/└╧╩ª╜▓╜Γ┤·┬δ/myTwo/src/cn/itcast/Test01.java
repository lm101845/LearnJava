package cn.itcast;

import com.itheima_01.Student;
//import com.itheima_02.Teacher;


public class Test01 {
    public static void main(String[] args) {
        Student s = new Student();
        s.study();

//        Teacher t = new Teacher();
    }
}
