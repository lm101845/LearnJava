package com.itheima_01;

@FunctionalInterface
public interface MyInterface {
    void show();

//    void method();
}
