package com.itheima_03;

public class JumppingOperator {

    public void useJumpping(Jumpping j) { //Jumpping j = new Cat();
        j.jump();
    }

    public Jumpping getJumpping() {
        Jumpping j = new Cat();
        return j;
    }

}
