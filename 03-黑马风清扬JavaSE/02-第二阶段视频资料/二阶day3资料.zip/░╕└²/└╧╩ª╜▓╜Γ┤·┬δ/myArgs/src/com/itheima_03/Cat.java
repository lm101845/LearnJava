package com.itheima_03;

public class Cat implements Jumpping {

    @Override
    public void jump() {
        System.out.println("猫可以跳高了");
    }
}
