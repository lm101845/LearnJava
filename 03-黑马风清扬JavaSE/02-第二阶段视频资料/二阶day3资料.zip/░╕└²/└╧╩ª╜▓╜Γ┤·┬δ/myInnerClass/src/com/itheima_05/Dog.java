package com.itheima_05;

public class Dog implements Jumpping {

    @Override
    public void jump() {
        System.out.println("狗可以跳高了");
    }
}
