package com.itheima_04;

public interface Inter {

    void show();

}
