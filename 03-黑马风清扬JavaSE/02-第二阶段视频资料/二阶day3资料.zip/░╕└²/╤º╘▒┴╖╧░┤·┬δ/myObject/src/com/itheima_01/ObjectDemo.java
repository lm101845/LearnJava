package com.itheima_01;

/*
    Object 是类层次结构的根，每个类都可以将 Object 作为超类。所有类都直接或者间接的继承自该类
 */
public class ObjectDemo {
    public static void main(String[] args) {
    

    }
}
