package com.itheima_05;

/*
    跳高接口
 */
public interface Jumpping {

    void jump();

}
