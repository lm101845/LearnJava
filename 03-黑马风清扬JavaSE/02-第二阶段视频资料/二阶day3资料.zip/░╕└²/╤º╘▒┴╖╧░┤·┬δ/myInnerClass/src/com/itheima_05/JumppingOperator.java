package com.itheima_05;

/*
    接口操作类，里面有一个方法，方法的参数是接口名
 */
public class JumppingOperator {

    public void method(Jumpping j) { 
        j.jump();
    }

}
