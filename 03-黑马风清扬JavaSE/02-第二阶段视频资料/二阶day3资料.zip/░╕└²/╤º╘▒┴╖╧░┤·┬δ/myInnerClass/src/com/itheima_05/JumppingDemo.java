package com.itheima_05;

/*
    测试类
 */
public class JumppingDemo {
    public static void main(String[] args) {
        //需求：创建接口操作类的对象，调用method方法
        
    }
}
