package com.itheima;

/*
    System类的常用方法
 */
public class SystemDemo {
    public static void main(String[] args) {
        //public static void exit(int status)：终止当前运行的 Java 虚拟机，非零表示异常终止


        //public static long currentTimeMillis()：返回当前时间(以毫秒为单位)

    }
}
