package com.itheima_03;

public class JumppingOperator {

    public void useJumpping(Jumpping j) {
        j.jump();
    }

}
