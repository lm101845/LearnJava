package com.itheima_01;

public class CatOperator {

    public void useCat(Cat c) {
        c.eat();
    }
	
}
