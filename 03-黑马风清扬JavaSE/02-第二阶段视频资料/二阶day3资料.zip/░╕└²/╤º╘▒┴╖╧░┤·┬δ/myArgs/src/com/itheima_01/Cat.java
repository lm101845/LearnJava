package com.itheima_01;

public class Cat {

    public void eat() {
        System.out.println("猫吃鱼");
    }

}
