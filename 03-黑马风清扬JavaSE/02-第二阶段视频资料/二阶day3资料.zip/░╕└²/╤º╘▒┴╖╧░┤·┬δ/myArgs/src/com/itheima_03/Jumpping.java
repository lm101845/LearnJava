package com.itheima_03;

public interface Jumpping {

    void jump();

}
