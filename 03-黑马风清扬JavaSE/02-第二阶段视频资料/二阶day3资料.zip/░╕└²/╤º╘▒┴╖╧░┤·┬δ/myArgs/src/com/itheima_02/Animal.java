package com.itheima_02;

public abstract class Animal {

    public abstract void eat();

}
