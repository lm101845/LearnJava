public class HelloWorld {
	public static void main(String[] args) {
		system.out.println("HelloWorld")��
	}
}