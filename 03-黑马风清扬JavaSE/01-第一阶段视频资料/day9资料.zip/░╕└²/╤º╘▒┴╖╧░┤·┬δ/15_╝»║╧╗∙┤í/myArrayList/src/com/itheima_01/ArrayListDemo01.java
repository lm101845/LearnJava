package com.itheima_01;

/*
    ArrayList构造方法：
        public ArrayList​()：创建一个空的集合对象

    ArrayList添加方法：
        public boolean add(E e)：将指定的元素追加到此集合的末尾
        public void add(int index,E element)：在此集合中的指定位置插入指定的元素
 */
public class ArrayListDemo01 {
    public static void main(String[] args) {

    }
}
