package com.itheima_04;
/*
    方法注意事项：
        方法不能嵌套定义
        void表示无返回值，可以省略return，也可以单独的书写return，后面不加数据
 */
public class MethodDemo {
    public static void main(String[] args) {

    }

}
