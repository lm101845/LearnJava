package com.itheima_05;

/*
    方法重载：
        多个方法在同一个类中
        多个方法具有相同的方法名
        多个方法的参数不相同，类型不同或者数量不同
 */
public class MethodDemo {
    public static void main(String[] args) {
        
    }

    //需求1：求两个int类型数据和的方法


    //需求2：求两个double类型数据和的方法


    //需求3：求三个int类型数据和的方法
	

}
